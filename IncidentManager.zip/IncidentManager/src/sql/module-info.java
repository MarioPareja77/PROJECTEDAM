module IncidentManager{
    requires java.desktop;
	requires java.sql;
}
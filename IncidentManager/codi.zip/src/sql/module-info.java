module IncidentManager{
    requires java.desktop;
	requires java.sql;
	exports org.mindrot.jbcrypt;
    requires java.mail;
    requires java.activation;
}